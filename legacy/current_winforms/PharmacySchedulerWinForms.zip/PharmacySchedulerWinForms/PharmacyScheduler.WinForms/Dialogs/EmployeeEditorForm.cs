using PharmacyScheduler.Core;
using PharmacyScheduler.Core.Models;

namespace PharmacyScheduler.WinForms.Dialogs;

public sealed class EmployeeEditorForm : Form
{
    private readonly TextBox _txtFullName = new() { Dock = DockStyle.Fill };
    private readonly TextBox _txtDisplayName = new() { Dock = DockStyle.Fill };
    private readonly DateTimePicker _dtBirth = new() { Format = DateTimePickerFormat.Short, Dock = DockStyle.Left, Width = 120 };
    private readonly ComboBox _cmbRole = new() { Dock = DockStyle.Left, DropDownStyle = ComboBoxStyle.DropDownList, Width = 240 };
    private readonly NumericUpDown _numMonthly = new() { Dock = DockStyle.Left, Width = 120, DecimalPlaces = 1, Minimum = 0, Maximum = 744, Increment = 0.5m };
    private readonly NumericUpDown _numDaily = new() { Dock = DockStyle.Left, Width = 120, DecimalPlaces = 1, Minimum = 0, Maximum = 24, Increment = 0.5m };
    private readonly TextBox _txtPreferred = new() { Dock = DockStyle.Fill };
    private readonly TextBox _txtForbidden = new() { Dock = DockStyle.Fill };
    private readonly CheckBox _chkActive = new() { Text = "Aktív, beosztható", AutoSize = true, Checked = true };
    private readonly CheckedListBox _lstTimeTypes = new() { CheckOnClick = true, Height = 120 };
    private readonly CheckedListBox _lstLocations = new() { CheckOnClick = true, Height = 120 };

    public EmployeeEditorForm(IReadOnlyList<Location> locations, Employee? employee = null)
    {
        Text = employee is null ? "Új dolgozó" : "Dolgozó szerkesztése";
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterParent;
        MaximizeBox = false;
        MinimizeBox = false;
        Width = 680;
        Height = 650;

        Model = employee is null
            ? new Employee()
            : new Employee
            {
                Id = employee.Id,
                FullName = employee.FullName,
                DisplayName = employee.DisplayName,
                BirthDate = employee.BirthDate,
                Role = employee.Role,
                MonthlyHoursLimit = employee.MonthlyHoursLimit,
                MaxDailyHours = employee.MaxDailyHours,
                PreferredWindows = employee.PreferredWindows,
                ForbiddenWindows = employee.ForbiddenWindows,
                IsActive = employee.IsActive,
                AllowedLocationIds = employee.AllowedLocationIds.ToList(),
                AllowedTimeTypes = employee.AllowedTimeTypes.ToList()
            };

        _cmbRole.DataSource = Enum.GetValues<EmployeeRole>();
        _cmbRole.Format += (_, e) =>
        {
            if (e.ListItem is EmployeeRole role) e.Value = role.ToDisplayText();
        };

        foreach (var tt in Enum.GetValues<TimeType>())
        {
            _lstTimeTypes.Items.Add(tt, Model.AllowedTimeTypes.Contains(tt));
        }

        foreach (var location in locations)
        {
            var idx = _lstLocations.Items.Add(location);
            _lstLocations.SetItemChecked(idx, Model.AllowedLocationIds.Count == 0 || Model.AllowedLocationIds.Contains(location.Id));
        }

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 11,
            Padding = new Padding(12)
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 170));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        layout.Controls.Add(new Label { Text = "Teljes név:", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 0);
        layout.Controls.Add(_txtFullName, 1, 0);
        layout.Controls.Add(new Label { Text = "Megjelenítési név:", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 1);
        layout.Controls.Add(_txtDisplayName, 1, 1);
        layout.Controls.Add(new Label { Text = "Születési idő:", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 2);
        layout.Controls.Add(_dtBirth, 1, 2);
        layout.Controls.Add(new Label { Text = "Szerepkör:", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 3);
        layout.Controls.Add(_cmbRole, 1, 3);
        layout.Controls.Add(new Label { Text = "Havi keret (óra):", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 4);
        layout.Controls.Add(_numMonthly, 1, 4);
        layout.Controls.Add(new Label { Text = "Max. napi óra:", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 5);
        layout.Controls.Add(_numDaily, 1, 5);
        layout.Controls.Add(new Label { Text = "Preferált idősávok:", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 6);
        layout.Controls.Add(_txtPreferred, 1, 6);
        layout.Controls.Add(new Label { Text = "Tiltott idősávok:", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 7);
        layout.Controls.Add(_txtForbidden, 1, 7);
        layout.Controls.Add(new Label { Text = "Engedélyezett időtípusok:", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 8);
        layout.Controls.Add(_lstTimeTypes, 1, 8);
        layout.Controls.Add(new Label { Text = "Telephelyek:", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 9);
        layout.Controls.Add(_lstLocations, 1, 9);

        var bottomPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
        var ok = new Button { Text = "OK", DialogResult = DialogResult.OK, Width = 100 };
        var cancel = new Button { Text = "Mégse", DialogResult = DialogResult.Cancel, Width = 100 };
        bottomPanel.Controls.Add(ok);
        bottomPanel.Controls.Add(cancel);
        bottomPanel.Controls.Add(_chkActive);
        ok.Click += (_, _) => SaveBack();
        layout.Controls.Add(bottomPanel, 1, 10);

        Controls.Add(layout);
        AcceptButton = ok;
        CancelButton = cancel;

        _txtFullName.Text = Model.FullName;
        _txtDisplayName.Text = Model.DisplayName;
        _dtBirth.Value = Model.BirthDate;
        _cmbRole.SelectedItem = Model.Role;
        _numMonthly.Value = Model.MonthlyHoursLimit;
        _numDaily.Value = Model.MaxDailyHours;
        _txtPreferred.Text = Model.PreferredWindows;
        _txtForbidden.Text = Model.ForbiddenWindows;
        _chkActive.Checked = Model.IsActive;
    }

    public Employee Model { get; }

    private void SaveBack()
    {
        if (string.IsNullOrWhiteSpace(_txtFullName.Text))
        {
            MessageBox.Show(this, "A teljes név kötelező.", "Hiányzó adat", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            DialogResult = DialogResult.None;
            return;
        }

        if (string.IsNullOrWhiteSpace(_txtDisplayName.Text))
        {
            MessageBox.Show(this, "A megjelenítési név kötelező.", "Hiányzó adat", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            DialogResult = DialogResult.None;
            return;
        }

        Model.FullName = _txtFullName.Text.Trim();
        Model.DisplayName = _txtDisplayName.Text.Trim();
        Model.BirthDate = _dtBirth.Value.Date;
        Model.Role = (EmployeeRole)_cmbRole.SelectedItem!;
        Model.MonthlyHoursLimit = _numMonthly.Value;
        Model.MaxDailyHours = _numDaily.Value;
        Model.PreferredWindows = _txtPreferred.Text.Trim();
        Model.ForbiddenWindows = _txtForbidden.Text.Trim();
        Model.IsActive = _chkActive.Checked;

        Model.AllowedTimeTypes = _lstTimeTypes.CheckedItems.Cast<TimeType>().ToList();
        Model.AllowedLocationIds = _lstLocations.CheckedItems.Cast<Location>().Select(x => x.Id).ToList();
    }
}
