using PharmacyScheduler.Core.Models;
using PharmacyScheduler.Core.Services;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace PharmacyScheduler.WinForms.Infrastructure;

public sealed class PdfExportService
{
    private readonly ScheduleQueryService _queryService = new();

    public void Export(AppData data, SchedulePlan schedule, ValidationReport report, string filePath)
    {
        var rows = _queryService.FlattenSchedule(data, schedule);

        Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4.Landscape());
                page.Margin(18);
                page.DefaultTextStyle(x => x.FontSize(10));

                page.Header().Column(column =>
                {
                    column.Item().Text("Gyógyszertári beosztás export").FontSize(18).Bold();
                    column.Item().Text($"{schedule.Name} • {schedule.PeriodStart:yyyy-MM-dd} - {schedule.PeriodEnd:yyyy-MM-dd} • {schedule.Status.ToDisplayText()}");
                });

                page.Content().Column(column =>
                {
                    column.Spacing(8);

                    column.Item().Table(table =>
                    {
                        table.ColumnsDefinition(columns =>
                        {
                            columns.RelativeColumn(2);
                            columns.RelativeColumn(1);
                            columns.RelativeColumn(1);
                            columns.RelativeColumn(1);
                            columns.RelativeColumn(2);
                            columns.RelativeColumn(2);
                            columns.RelativeColumn(1);
                            columns.RelativeColumn(1);
                            columns.RelativeColumn(2);
                        });

                        table.Header(header =>
                        {
                            HeaderCell(header, "Telephely");
                            HeaderCell(header, "Dátum");
                            HeaderCell(header, "Kezd");
                            HeaderCell(header, "Vég");
                            HeaderCell(header, "Dolgozó");
                            HeaderCell(header, "Szerepkör");
                            HeaderCell(header, "Típus");
                            HeaderCell(header, "Óra");
                            HeaderCell(header, "Megjegyzés");
                        });

                        foreach (var row in rows)
                        {
                            BodyCell(table, row.LocationName);
                            BodyCell(table, row.Date.ToString("yyyy-MM-dd"));
                            BodyCell(table, row.Start.ToString("HH:mm"));
                            BodyCell(table, row.End.ToString("HH:mm"));
                            BodyCell(table, row.EmployeeDisplayName);
                            BodyCell(table, row.RoleName);
                            BodyCell(table, row.TimeTypeName);
                            BodyCell(table, row.Hours.ToString("0.##"));
                            BodyCell(table, row.Note);
                        }
                    });

                    if (report.Issues.Count > 0)
                    {
                        column.Item().Text("Ellenőrzések").Bold().FontSize(12);
                        foreach (var issue in report.Issues.Take(25))
                        {
                            column.Item().Text($"• [{issue.Severity.ToDisplayText()}] {issue.Message}");
                        }

                        if (report.Issues.Count > 25)
                        {
                            column.Item().Text($"... további {report.Issues.Count - 25} ellenőrzési tétel");
                        }
                    }
                });

                page.Footer()
                    .AlignCenter()
                    .Text($"Generálva: {DateTime.Now:yyyy-MM-dd HH:mm}");
            });
        }).GeneratePdf(filePath);
    }

    private static void HeaderCell(TableDescriptor table, string text)
    {
        table.Cell().Border(1).Background(Colors.Grey.Lighten2).Padding(4).Text(text).Bold();
    }

    private static void BodyCell(TableDescriptor table, string text)
    {
        table.Cell().Border(1).Padding(3).Text(text ?? string.Empty);
    }
}
