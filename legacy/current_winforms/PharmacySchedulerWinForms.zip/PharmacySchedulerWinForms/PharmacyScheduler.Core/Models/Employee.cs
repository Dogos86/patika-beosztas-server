namespace PharmacyScheduler.Core.Models;

public sealed class Employee
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string FullName { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public DateTime BirthDate { get; set; } = new DateTime(1990, 1, 1);
    public EmployeeRole Role { get; set; } = EmployeeRole.Pharmacist;
    public decimal MonthlyHoursLimit { get; set; } = 168m;
    public decimal MaxDailyHours { get; set; } = 8m;
    public string PreferredWindows { get; set; } = string.Empty;
    public string ForbiddenWindows { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
    public List<TimeType> AllowedTimeTypes { get; set; } = Enum.GetValues<TimeType>().ToList();
    public List<Guid> AllowedLocationIds { get; set; } = new();

    public override string ToString() => string.IsNullOrWhiteSpace(DisplayName) ? FullName : DisplayName;
}
